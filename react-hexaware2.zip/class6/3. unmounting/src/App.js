import Parent from "./components/Unmounting1";

function App() {
  return (
    <div className="container">
      <Parent />
    </div>
  );
}

export default App;
