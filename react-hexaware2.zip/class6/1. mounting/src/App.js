import Header from "./components/Mounting3";

function App() {
  return (
    <div className="container">
      {/* <Header newname="John" /> */}

      <Header />
    </div>
  );
}

export default App;
