import Photos from "./components/Photos";
import Posts from "./components/Posts";

function App() {
  return (
    <div className="container">
        {/* <Posts /> */}
        <Photos />

    </div>
  );
}

export default App;
