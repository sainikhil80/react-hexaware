# Conditional Rendering
# List
# Http Calls


# Conditional Rendering
- if / else
- element value
- ternery opeartor
- circut breaker

(condition) ? <statement1> : <statement2>

# List
key - we have to provide a unique key to every element of the row when generating list


# Http

- Get - read
- Post - create / insert
- Put - update
- Delete - delete


# Http Library
- axios
- fetch
- request


> npm i axios --save	 // project depedency	
> npm i axios --save-dev // development depedency


200 - Ok - success
201 - created
400 - bad request
401 - unauthorzied
404 - not found
500 - server error







