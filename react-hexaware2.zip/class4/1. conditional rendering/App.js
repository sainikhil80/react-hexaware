import User from "./components/User";

function App() {
  return (
    <div className="container">
  
      <User />
     
    </div>
  );
}

export default App;
