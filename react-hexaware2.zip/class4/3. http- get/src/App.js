import Posts from "./components/Posts";

function App() {
  return (
    <div className="container">
        <Posts />

    </div>
  );
}

export default App;
