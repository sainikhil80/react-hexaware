import Employees from "./components/Employees";
import Person from "./components/Person";

function App() {
  return (
    <div className="container">
  
   {/* <Person /> */}

   <Employees />

    </div>
  );
}

export default App;
