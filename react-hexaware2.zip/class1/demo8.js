let str1 = 'hello';
let str2 = "world";

let firstname = 'Mark';
let lastName ='Smith';

// let fullName = firstname + ' ' +lastName;
let fullName = `${firstname} ${lastName}`
console.log(fullName)
let mesage = 'hello'+
'world'+
'abc';


let message2 = `
a
b
c
d

`
