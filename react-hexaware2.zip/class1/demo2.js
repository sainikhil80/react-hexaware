// let a = 10;
// console.log(a)
// a = 20;
// console.log(a)

const a = 10;
console.log(a);
a = 20;
console.log(a);