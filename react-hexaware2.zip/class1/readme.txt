# Setup

1. VSCode
2. Node

> node --version
> npm --version

> code .

> node <file_name>

# Introduction to ES6 / ECMA Script

ECMAScript stands for European Compiter Manufactuere Association Script
it lays out the specification and basic rules of language on which  javascript is based on

ES6 / ECMAScript 2015 was the second major release for javascript

- let
- const
- default parameters
- rest parameters
- spread operator
- destructing
- for..of loop
- temlate literl
- modules
- map()
- arrow function
- class
- inheritence
etc


# let 
the let keyword is similar to the var keyword except that these variable are blocked-scope

# consta new keyword of declaring a constant by using the const keyword
the const keyword create a read-only reference variable
variable declared by the const keyword can't be reassigned

# default parameters

# rest parameters
Es6 provide a new kind of parameters called rest parameters that has a prefix of three dots (...)
a rest parameter allow you to represent an identified number of arguments as an array
just make that rest parameter should be the parameter of the function
the last parameetrs is prefixes with three dots

# spread opeartor
Es6 provide a new opeartor called spread opeartor that consist of three dots (...)
the spread opeartor allow you to spread out elements of an iterable object such as an array, map or set

# destructuring
ES6 provides a new feature called destructuring asignment that allow you to destructure properties
of an object or the elements of an array into individual variables

# for..of loop

# template literal
prior to ES6 we use single or double quote to wrap a string
backtick(`)

multiline string
string formatting
html eascaping

# Arrow function
ES6 arrow function provide you with an alternative way to write a shorter syntex compare to function 
expression


# map function
the map() method create a new array with the result of calling a function for every array elements
the map() method calls the provided function once for each elements in an array in order
