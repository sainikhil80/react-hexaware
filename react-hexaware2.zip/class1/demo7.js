let scores = [82, 85, 90, 95]

for(let score of scores){
    console.log(score)
}