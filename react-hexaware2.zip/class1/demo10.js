const numbers = [11,22,33,44,55];
const newArray = numbers.map(a => a * 10);

console.log(numbers)
console.log(newArray)

const names = ['Mark', 'Paul', 'Watson', 'John'];
const newnames = names.map(n => 'Mr.'+ n);

console.log(names);
console.log(newnames);