import Register from "./components/Register";

function App() {
  return (
    <div className="container">
        {/* <h1>App</h1> */}

      <Register />
    </div>
  );
}

export default App;
