import FormClass from "./components/FromClass";
import Header from "./components/MultipleFormClass";

function App() {
  return (
    <div className="container">
        {/* <h1>App</h1> */}

      {/* <FormClass /> */}

      <Header />

    </div>
  );
}

export default App;
