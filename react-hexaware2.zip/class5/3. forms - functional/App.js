// import FormClass from "./components/FromClass";
// import Header from "./components/MultipleFormClass";

import Header from "./components/FormFunction";

function App() {
  return (
    <div className="container">
        {/* <h1>App</h1> */}

      {/* <FormClass /> */}

      <Header />

    </div>
  );
}

export default App;
