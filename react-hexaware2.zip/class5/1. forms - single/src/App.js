import FormClass from "./components/FromClass";

function App() {
  return (
    <div className="container">
        {/* <h1>App</h1> */}

      <FormClass />

    </div>
  );
}

export default App;
