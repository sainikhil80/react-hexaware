import React from 'react';

const Home =() => {
    return(
    <div>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim quo, odio corrupti debitis consectetur, iste animi ipsa quia tempora ratione molestiae quibusdam earum magnam commodi quasi labore? Debitis ipsa fugit rerum praesentium illum repellat, eos quasi quisquam iure quod, officia laborum repudiandae amet nesciunt. Officiis eveniet impedit obcaecati deleniti accusamus at optio, iusto voluptate facilis nisi quia quisquam perspiciatis commodi recusandae quod! Qui dicta atque illum reprehenderit laborum quas, doloribus sunt asperiores quaerat quam saepe, tenetur impedit aliquid fugiat possimus culpa recusandae excepturi voluptatem quos quibusdam omnis adipisci. Exercitationem iusto provident molestias officiis accusamus excepturi quo sint fugit dolores facilis!</p>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda repellendus nam deserunt ratione, debitis suscipit saepe recusandae dolores magni, voluptatem quam facilis? Voluptates porro nobis quidem nostrum. Reiciendis, tempore illum assumenda fugiat iusto quis repellat sint, quisquam esse beatae est! Quisquam inventore consequatur voluptatum, tempore saepe dicta voluptates! Necessitatibus deleniti exercitationem sed voluptas rerum beatae quis, iste sunt quos magni delectus, perferendis itaque blanditiis ut iusto dignissimos, neque minima quod distinctio nemo inventore. Dignissimos, repellat. Ducimus illum tempora unde neque aliquid pariatur qui quis, eaque nemo debitis laboriosam officia! Sed blanditiis architecto nisi illum sunt adipisci, minima rem corporis earum?</p>
    </div>
    )
}
export default Home;