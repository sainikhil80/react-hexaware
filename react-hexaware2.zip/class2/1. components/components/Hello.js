import React, { Component } from 'react';

class Hello extends Component{
    render(){
        return <h1>Hello Component</h1>
    }
}
export default Hello;
