import React from 'react';

// function World(){
//     return <h1>World Componment</h1>
// }

const World = () => {
    return <h1>World Component</h1>
}

export default World;