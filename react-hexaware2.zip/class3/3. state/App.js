import Hello from "./components/Hello";
import World from "./components/World";

function App() {
  return (
    <div className="container">
  
      {/* <Hello /> */}
      <World />
     
    </div>
  );
}

export default App;
