import ClassEvent from "./components/ClassEvent";
import FunctionEvent from "./components/FunctionEvent";

function App() {
  return (
    <div className="container">
  
    {/* <ClassEvent /> */}

    <FunctionEvent />
     
    </div>
  );
}

export default App;
