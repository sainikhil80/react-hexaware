import React from 'react';

const CounterOutput = (props) => {
    return(
        <h1>Counter: { props.data }</h1>
    )
}
export default CounterOutput;